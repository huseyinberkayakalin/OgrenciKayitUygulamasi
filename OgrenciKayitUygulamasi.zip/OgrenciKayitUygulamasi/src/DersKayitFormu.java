import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class DersKayitFormu extends JFrame {
	private static final long serialVersionUID = 1L;
	private JTextField dersKoduField, dersAdiField, dersDonemField;

    public DersKayitFormu() {
        setTitle("Ders Kayıt Formu");
        setSize(300, 200);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JLabel dersKoduLabel = new JLabel("Ders Kodu:");
        JLabel dersAdiLabel = new JLabel("Ders Adı:");
        JLabel dersDonemLabel = new JLabel("Ders Dönemi:");

        dersKoduField = new JTextField(15);
        dersAdiField = new JTextField(15);
        dersDonemField = new JTextField(15);

        JButton kaydetButton = new JButton("Kaydet");
        kaydetButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                kaydetButtonActionPerformed(e);
            }
        });

        JPanel panel = new JPanel(new GridLayout(4, 2));
        panel.add(dersKoduLabel);
        panel.add(dersKoduField);
        panel.add(dersAdiLabel);
        panel.add(dersAdiField);
        panel.add(dersDonemLabel);
        panel.add(dersDonemField);
        panel.add(new JLabel());
        panel.add(kaydetButton);

        add(panel);

        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void kaydetButtonActionPerformed(ActionEvent event) {
        String dersKodu = dersKoduField.getText();
        String dersAdi = dersAdiField.getText();
        String dersDonem = dersDonemField.getText();

        if (dersKodu.isEmpty() || dersAdi.isEmpty() || dersDonem.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Lütfen tüm alanları doldurun.", "Hata", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String dosyaAdi = "ders_kayitlar.txt";

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(dosyaAdi, true))) {
            String kayit = String.format("%s, %s, %s%n", dersKodu, dersAdi, dersDonem);
            writer.write(kayit);
            JOptionPane.showMessageDialog(this, "Ders kaydı başarıyla eklendi.", "Başarılı", JOptionPane.INFORMATION_MESSAGE);
            this.dispose(); 
        } catch (IOException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Dosya yazma hatası.", "Hata", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new DersKayitFormu();
            }
        });
    }
}
