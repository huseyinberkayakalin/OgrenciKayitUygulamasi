import java.util.ArrayList;
import java.util.List;

public class listeleme {
     public static List<Ders> tumDersler = new ArrayList<>();
     
}

