import java.util.ArrayList;
import java.util.List;

public class Ders {
	    
    private String dersKodu;
    private String dersAdi;
    private String dersDanismanHoca;
    private int dersKredisi;

    @Override
    public String toString() {
        return this.dersAdi;
    }

    public String getDersKodu() {
        return dersKodu;
    }

    public void setDersKodu(String dersKodu) {
        this.dersKodu = dersKodu;
    }

    public String getDersAdi() {
        return dersAdi;
    }

    public void setDersAdi(String dersAdi) {
        this.dersAdi = dersAdi;
    }

    public String getDersDanismanHoca() {
        return dersDanismanHoca;
    }

    public void setDersDanismanHoca(String dersDanismanHoca) {
        this.dersDanismanHoca = dersDanismanHoca;
    }

    public int getDersKredisi() {
        return dersKredisi;
    }

    public void setDersKredisi(int dersKredisi) {
        this.dersKredisi = dersKredisi;
    }
}
